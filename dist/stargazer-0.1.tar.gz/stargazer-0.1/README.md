# `stargazer`
![Replace with your own inspirational logo here](https://github.com/PFython/easypypi/blob/main/easypypi.png?raw=true)
Utility to crape emails and names of Github users (\'Stargazers\') who have starred a particular repository.  Includes a general purpose Repository class and (Github) User class.
### OVERVIEW

### INSTALLATION

```
pip install stargazer
```

### BASIC USE

```
import stargazer
```

### UNDER THE BONNET

### CONTRIBUTING

Contact Peter Fison

peter@southwestlondon.tv

### CREDITS
