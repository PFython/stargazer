# Tests for stargazer

from .stargazer import *

class Test_Group_1:
    def test_something(self):
        """ Something should happen when you run something() """
        assert something() == something_else
